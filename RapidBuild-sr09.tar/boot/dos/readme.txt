You can start the LiveCD from DOS prompt. Boot your DOS and type:

  X:
  CD \BOOT\DOS
  slax.bat

(replace X: by your CDROM drive letter)


If you do not have DOS installed, or it is not able to access your CD,
try to boot from a diskette. You can use FreeDos from http://www.freedos.org
which has already a CD drivers included
